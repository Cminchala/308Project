from flask import Flask, render_template, url_for, request, redirect,jsonify
from flask_sqlalchemy import SQLAlchemy

from requests import get
import json
import requests
from whoisapi import *

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ipQuery.db'
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)
  

class ipQuery(db.Model): ##REDO
    id = db.Column(db.Integer, primary_key = True)
    load_instance = True
    ip = db.Column(db.String(200)) ## ip column
    ipData = db.Column(db.String(200)) ## ip data column
    def __init__(self,ip,ipdata):
         self.ip = ip
         self.ipdata = ipdata

@app.route("/<ip_address>", methods = ["GET","POST"]) ##done
def curl(ip_address):
    if request.method == 'GET':
        urls = "http://ip-api.com/json/"
        urls += ip_address
        resp = requests.get(urls)
        ipdata = json.loads(resp.text)
        return ipdata
    else:
       return redirect('/ipinfo')


   


@app.errorhandler(404) ##DONE
def page_not_found(e):
    return redirect("/ipinfo")


@app.route('/ipinfo', methods=["GET", "POST"]) #DONE
def ipInfo():
    urls = "http://ip-api.com/json/"
    iper = {}
   
    if request.method == "POST":
        ipe = request.form.get("ip")
        if ipe == '':
            return "No IP Go Back and Enter a IP"
        ip = ipe
        
        urls += ip ##adds the url and ip together
        resp = requests.get(urls)
        ipdata = json.loads(resp.text)
        # ipdb = ipQuery(ip,ipdata)
        iper = ipdata
        # db.session.add(ip)
        # db.session.commit()
       
        return render_template("ipInfo.html", show_ip=iper)
    return render_template('ipInfo.html',show_ip = iper)
    


@app.route('/map/',methods = ['GET','POST'])  # NOT DONE YET
def mapInfo(): 
        lat = 0.0
        long = 0.0
        urls = "http://ip-api.com/json/"
        if request.method == "POST":
          iptomap = request.form.get("mapIP")
          ip = iptomap
          
          urls += ip
          resp = requests.get(urls)
          data = json.loads(resp.text)
        #   if(data['lat'] == ''  or data['lon'] ==''):
        #       return "No location data found"
          lat = data['lat']
          long = data['lon']
          
        return render_template("map.html",newlat= lat,newlong = long)
        return render_template("map.html",newlat= lat,newlong = long)
        

@app.route('/whois/', methods=['GET', 'POST']) #DONE
def whoIs():
    
    final = {}
    if request.method == "POST":
        ipe = request.form.get("whoisip")
        
        client = Client(api_key='at_T9t1Z67gZSNYozqSy88VT0XuSaU6p')
        client.parameters.output_format = 'json'
        
        final = json.loads(client.raw_data(ipe))

        return render_template("whois.html",show_whois = final)
    return render_template("whois.html",show_whois = final)


@app.route("/log/")
def logs():
    return render_template("logs.html",values = ipQuery.query.all())


if __name__ == "__main__":
    # db.create_all
    app.run(debug =True)

